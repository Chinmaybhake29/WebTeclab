npm init -y


call back function


show dbs
use userdetails
> db.createCollection('user')
show collections

1)insert()
2)insertOne()
3)insertMany()

db.users.insert([
{"name" :"Pranit", 
"age":23,
"place":"Sangamner"},

{"name" :"Tanmay", 
"age":23,
"place":"nashik"},

{"name" :"sid",
 "age":23,
 "place":"pune"}
]);

db.user.find();

db.users.find({place:"pune"})

db.users.remove({"place":"pune"});

db.users.update(
    {
    "place":"nashik"
    },
    {
    $set:{
        "name":"Mahavir",
    "age":24
    }
});

npm i mongoose