var express = require("express");
var mongoose = require("mongoose");
var db = require("./database/db.js");
var cors = require("cors");
// console.log(db);

var mysql = require("mysql");
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "cdac",
});

db();

const Schema = mongoose.Schema;

const usersschema = new Schema({
  name: String,
  age: Number,
  place: String,
});

const usermodel = mongoose.model("user", usersschema);

var app = express();
app.use(cors());
app.use(express.json());

app.get("/users", async function (req, res) {
  try {
    var result = await usermodel.find();
    res.send(result);
  } catch (err) {
    res.send(err.message);
  }
});
app.post("/users", async function (req, res) {
  try {
    var record = new usermodel(req.body);
    var ans = await record.save();
    res.send("record inserted");
  } catch (err) {
    res.send(err.message);
  }
});

app.put("/users", function (req, res) {
  res.send("update data form database");
});
app.delete("/users", function (req, res) {
  res.send("delete data form database");
});

//mysql databases
app.get("/userinfo", function (req, res) {
  connection.query("select * from emp", function (err, result) {
    if (err) {
      res.send(err.message);
    } else {
      res.send(result);
    }
  });
});

app.post("/userinfo", function (req, res) {
  console.log(req.body);
  connection.query("insert into emp set ?", req.body, function (err, result) {
    if (err) {
      res.send(err.message);
    } else {
      res.send("user added");
    }
  });
});

app.listen(9000);
